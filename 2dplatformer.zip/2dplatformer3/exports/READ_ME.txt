The game currently only has one room
You can kill the enemies with melee or ranged attacks (although they don't have health bar as couldn't finish in time)

Controls
Jump: spacebar
Move left: a
Move right: d
Dash: shift
Melee attack: left CLick
Ranged attack: right click
element switching: mouse wheel (if that doesn't work then squarebrackets)

Swimming controls
left: a
right: d
up: w or space
down: s
